<div id="carouselExampleIndicators" class="carousel slide bg-primary" data-bs-ride="carousel" >
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRd1TV6F79DQaHvrNU60Dx1ansavn0RcZq4FJsyNP_4OQ&s" class="d-block mx-auto" alt="Imagen1" style="max-width: 100%;" width="450px"; height="300px">
        </div>
        <div class="carousel-item">
            <img src="https://abono.in/wp-content/uploads/2022/04/2-Bags-With-Content.jpg" class="d-block mx-auto" alt="Imagen2" style="max-width: 100%;" width="450px"; height="300px">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div><?php /**PATH C:\GitHub\PI_Tlacualli\TLACUALLI\resources\views/partials/carrusel.blade.php ENDPATH**/ ?>