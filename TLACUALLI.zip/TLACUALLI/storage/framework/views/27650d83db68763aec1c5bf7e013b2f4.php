<?php $__env->startSection('titulo','Productos'); ?>
<?php $__env->startSection('contenido'); ?>

<div class="row mt-5">
    <div class="col-2">
        <div class="sticky-top">
            <?php echo $__env->make('partials.productos1.filtros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="col-8">  
        <h1 class="text-center">Productos</h1>
        <div class="row">
            <div class="col-5">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Buscar productos ..." aria-label="Buscar productos" aria-describedby="button-search">
                    <button class="btn btn-outline-primary" type="button" id="button-search"><i class="bi bi-search"></i> Buscar</button>
                </div>        
            </div>
            <div class="col-5"></div>
            <div class="col-2 d-flex justify-content-end">
                <?php if(session()->has('id_usuario')): ?>
                <button type="button" class="btn btn-outline-success" onclick="window.location.href='<?php echo e(url('/productos')); ?>'">
                    <i class="bi bi-bag-plus"></i> Productos
                </button>
                <?php endif; ?>
            </div>
        </div>
        <div class="row p-2">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 p-2">
                    <?php echo $__env->make('producto.card_producto', ['producto' => $producto], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="col-2">
        <div class="sticky-top pe-3">
            <br>
            <?php echo $__env->make('partials.productos1.carrusel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br>
            <?php echo $__env->make('partials.publicaciones.carrusel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br>
            <?php echo $__env->make('partials.talleres.carrusel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php echo $__env->make('partials.productos1.script_productos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git\PI_Tlacualli\TLACUALLI\resources\views/producto/productosCards.blade.php ENDPATH**/ ?>