<?php if($errors->first('_nu')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_nu')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_rol')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_rol')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_email')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_email')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_fn')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_fn')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_tel')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_tel')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_ap')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_ap')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_am')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_am')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_pd')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_pd')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_pdc')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_pdc')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_sx')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_sx')); ?>

</div>
<?php endif; ?>
<?php if($errors->first('_rfc')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e($errors->first('_rfc')); ?>

</div>
<?php endif; ?>

<?php /**PATH D:\Git\PI_Tlacualli\TLACUALLI\resources\views/partials/login/errores_login.blade.php ENDPATH**/ ?>