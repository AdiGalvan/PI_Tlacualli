<?php $__env->startSection('titulo','Servicios'); ?>
<?php $__env->startSection('contenido'); ?>

<p></p>
<center><h1>Mis solicitudes</h1></center>
<p></p>
<div class="container mt-3">
    <form class="d-flex" role="search" action="<?php echo e(route('servicios.search')); ?>" method="GET">
        <input class="form-control me-2" type="text" name="cliente" placeholder="Buscar por Cliente" aria-label="Buscar">
        <input class="form-control me-2" type="text" name="proveedor" placeholder="Buscar por Proveedor" aria-label="Buscar">
        <input class="form-control me-2" type="date" name="fecha" placeholder="Buscar por Fecha" aria-label="Buscar">
        <button class="btn btn-success" type="submit">Buscar</button>
    </form>
</div>

<div class="container mt-4 d-flex justify-content-end">
    <a href="<?php echo e(route('servicios.create')); ?>" class="btn btn-warning">Nueva solicitud</a>
</div>

<div class="container mt-3">
    <?php if(session()->has('noResults')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('noResults')); ?></strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php if(session()->has('confirmacion')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong><?php echo e(session('confirmacion')); ?></strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Cliente</th>
                <th>Proveedor</th>
                <th>Descripción</th>
                <th>Tipos de servicio</th>
                <th>Fecha</th>
                <th>Acciones</th>
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($solicitud->id); ?></td>
                <td><?php echo e($solicitud->cliente); ?></td>
                <td><?php echo e($solicitud->proveedor); ?></td>
                <td><?php echo e($solicitud->descripcion); ?></td>
                <td><?php echo e($solicitud->tipo_servicio); ?></td>
                <td><?php echo e($solicitud->fecha); ?></td>
                <td>
                    <a href="<?php echo e(route('servicios.edit', ['id' => $solicitud->id])); ?>" class="btn btn-primary">Editar</a>
                    <form action="<?php echo e(route('servicios.editForm', ['id' => $solicitud->id])); ?>" method="GET" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git\PI_Tlacualli\TLACUALLI\resources\views/servicios/mis_servicios.blade.php ENDPATH**/ ?>