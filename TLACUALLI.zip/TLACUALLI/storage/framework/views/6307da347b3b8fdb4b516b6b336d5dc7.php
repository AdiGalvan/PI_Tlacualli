<div class="container mt-5">
    <div class="row align-items-center justify-content-center">
        <div class="col-1 text-center me-3">
            <img src="https://th.bing.com/th/id/OIP.4eIcrrOQ4rEn9eKP8kYAfAAAAA?rs=1&pid=ImgDetMain" class="img-fluid rounded-circle" alt="Aliado 1" style="width: 100px;">
        </div>
        <div class="col-1 text-center me-3">
            <img src="https://th.bing.com/th/id/OIP.cz4AxjwaMP-PaS9uEyl_bQHaHM?rs=1&pid=ImgDetMain" class="img-fluid rounded-circle" alt="Aliado 2" style="width: 100px;">
        </div>
        <div class="col-1 text-center me-3">
            <img src="https://th.bing.com/th/id/OIP.jW2NYWJxh-0TQJfjHLgTYwHaHZ?rs=1&pid=ImgDetMain" class="img-fluid rounded-circle" alt="Aliado 3" style="width: 100px;">
        </div>
        <div class="col-1 text-center me-3">
            <img src="https://th.bing.com/th/id/OIP.Pbjt7iKrRaCirYdOFVbBogHaHZ?rs=1&pid=ImgDetMain" class="img-fluid rounded-circle" alt="Aliado 4" style="width: 100px;">
        </div>
        <div class="col-1 text-center me-3">
            <img src="https://elchicanorestaurant.com/wp-content/uploads/2022/07/LOGOS-copy.png" class="img-fluid rounded-circle" alt="Aliado 5" style="width: 100px;">
        </div>
        <div class="col-1 text-center me-3">
            <img src="https://mir-s3-cdn-cf.behance.net/project_modules/disp/12039315389066.5603855b0321b.png" class="img-fluid rounded-circle" alt="Aliado 6" style="width: 100px;">
        </div>
        <div class="col-1 text-center me-3">
            <img src="https://th.bing.com/th/id/OIP.cz4AxjwaMP-PaS9uEyl_bQHaHM?rs=1&pid=ImgDetMain" class="img-fluid rounded-circle" alt="Aliado 7" style="width: 100px;">
        </div>
        <div class="col-1 text-center me-3">
            <img src="https://i.pinimg.com/originals/e4/d1/2f/e4d12f5b5cda820081e6f66b0ee406a4.jpg" class="img-fluid rounded-circle" alt="Aliado 8" style="width: 100px;">
        </div>
    </div>
</div>
<?php /**PATH C:\GitHub\PI_Tlacualli\TLACUALLI\resources\views/partials/home/alidados.blade.php ENDPATH**/ ?>