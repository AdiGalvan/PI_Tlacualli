<?php $__env->startSection('titulo','TablaProductos'); ?>
<?php $__env->startSection('contenido'); ?>

<div class="row mt-5">
    <div class="col-2">
        <div class="sticky-top">
            <?php echo $__env->make('partials.productos1.filtros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="col-8">  
        
    
            <h1 class="text-center">Tabla Productos</h1>
        
            <div class="row">
                <div class="col-5">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Buscar productos ..." aria-label="Buscar productos" aria-describedby="button-search">
                        <button class="btn btn-outline-primary" type="button" id="button-search"><i class="bi bi-search"></i> Buscar</button>
                    </div>        
                </div>
                <div class="col-5">
                </div>
                <div class="float-right col-2 justify-content-end">
                    <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-outline-primary btn-sm float-right"  data-placement="left"><i class="bi bi-bag-plus"></i>  Agregar Producto</a>
                 </div>
            </div>
                                    
            <div class="container-fluid mt-5">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success m-4">
                                    <p><?php echo e($message); ?></p>
                                </div>
                            <?php endif; ?>
        
                            <div class="card-body bg-white">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead class="thead">
                                            <tr>
                                                <th>No</th>
                                                
                                                <th>Nombre</th>
                                                <th>Descripcion</th>
                                                <th>Costo</th>
                                                <th>Stock</th>
                                                <th>Estatus</th>
                                                <th>Proveedor Id</th>
        
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(++$i); ?></td>
                                                    
                                                    <td><?php echo e($producto->nombre); ?></td>
                                                    <td><?php echo e($producto->descripcion); ?></td>
                                                    <td><?php echo e($producto->costo); ?></td>
                                                    <td><?php echo e($producto->stock); ?></td>
                                                    <td><?php echo e($producto->estatus); ?></td>
                                                    <td><?php echo e($producto->proveedor_id); ?></td>
        
                                                    <td>
                                                        <form action="<?php echo e(route('productos.destroy',$producto->id)); ?>" method="POST">
                                                            <a class="btn btn-sm btn-outline-warning" href="<?php echo e(route('productos.edit',$producto->id)); ?>"><i class="bi bi-pencil-square"></i></a>
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-outline-danger btn-sm"><i class="bi bi-trash3"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php echo $productos->links(); ?>

                    </div>
                </div>
            </div>
        
            <div class="row justify-content-center mt-5">
                <div class="col-auto">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
    </div>
    <div class="col-2">
        <div class="sticky-top pe-3">
            <br>
            <?php echo $__env->make('partials.productos1.carrusel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br>
            <?php echo $__env->make('partials.publicaciones.carrusel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br>
            <?php echo $__env->make('partials.talleres.carrusel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>



<?php echo $__env->make('partials.productos1.registrar_producto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.productos1.script_productos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Git\PI_Tlacualli\TLACUALLI\resources\views/producto/index.blade.php ENDPATH**/ ?>