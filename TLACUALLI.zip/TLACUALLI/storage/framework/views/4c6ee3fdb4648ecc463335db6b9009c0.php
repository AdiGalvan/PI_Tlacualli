
<div class="card mt-3">
    <h3 class="ms-2 mt-2">Categorias</h3>
        <ul>
            <li><a href="">Tesis</a></li>
            <li><a href="">Infografías</a></li>
            <li><a href="">Noticias</a></li>
            <li><a href="">Avisos</a></li>
            <li><a href="">Pamfletos</a></li>
        </ul>
  </div><?php /**PATH C:\GitHub\PI_Tlacualli\TLACUALLI\resources\views/partials/publicaciones/filtros.blade.php ENDPATH**/ ?>