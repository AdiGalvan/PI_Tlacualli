<div id="carrusel3" class="carousel slide" data-bs-ride="carousel" >
    <h3>Talleres</h3>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://i0.wp.com/labola.org/wp-content/uploads/2021/04/composta-banner.png?fit=1042%2C550&ssl=1" class="d-block mx-auto" alt="Imagen1" style="max-width: 100%;" width="450px"; height="100%">
        </div>
        <div class="carousel-item">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSp5BZBctFR1YfestgNxZt4Nxh6FJSvb8c7KWy5EF7jUg&s" class="d-block mx-auto" alt="Imagen2" style="max-width: 100%;" width="450px"; height="100%">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carrusel3" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carrusel3" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div><?php /**PATH D:\Git\PI_Tlacualli\TLACUALLI\resources\views/partials/talleres/carrusel.blade.php ENDPATH**/ ?>