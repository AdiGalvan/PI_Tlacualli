
<script>
    function showSweetAlert() {
        Swal.fire({
            position: "center",
            icon: "success",
            title: "Producto Agregado Correctamente!",
            showConfirmButton: false,
            timer: 1500
        });
    }
</script>


<script>
    function showSweetAlert1() {
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: "btn btn-outline-success",
                cancelButton: "btn btn-outline-danger me-3" 
            },
            buttonsStyling: false
        });
        swalWithBootstrapButtons.fire({
            title: "¿Estás seguro?",
            text: "¡No podrás revertir esto!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Sí, agregarlo",
            cancelButtonText: "No, cancelar",
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                swalWithBootstrapButtons.fire({
                    title: "¡Agregado!",
                    text: "El producto fue agregado correctamente.",
                    icon: "success"
                });
            } else if (result.dismiss === Swal.DismissReason.cancel) {
                swalWithBootstrapButtons.fire({
                    title: "Cancelado",
                    text: "El producto no se agregó :)",
                    icon: "error"
                });
            }
        });
    }
</script>

<?php if(session()->has('Confirmacion_login')): ?>
<script>
    Swal.fire(
        'Todo correcto',
        '<?php echo e(session('Confirmacion_login')); ?>',
        'success'
    )
</script>
<?php endif; ?>

<?php if(session()->has('Confirmacion_logout')): ?>
<script>
    Swal.fire(
        'Todo correcto',
        '<?php echo e(session('Confirmacion_logout')); ?>',
        'success'
    )
</script>
<?php endif; ?>

<?php if(session()->has('Confirmacion_registro')): ?>
<script>
    Swal.fire(
        'Todo correcto',
        '<?php echo e(session('Confirmacion_registro')); ?>',
        'success'
    )
</script>
<?php endif; ?>

<?php if(session()->has('Error_login')): ?>
<script>
    Swal.fire(
        'Error',
        '<?php echo e(session('Error_login')); ?>',
        'error'
    )
</script>
<?php endif; ?>

<?php if(session()->has('Confirmacion_update')): ?>
<script>
    Swal.fire(
        'Todo correcto',
        '<?php echo e(session('Confirmacion_update')); ?>',
        'success'
    )
</script>
<?php endif; ?>

<?php if(session()->has('Error_contraseña')): ?>
<script>
    Swal.fire(
        'Error',
        '<?php echo e(session('Error_contraseña')); ?>',
        'error'
    )
</script>
<?php endif; ?>

<?php if(session()->has('Confirmacion_cambio')): ?>
<script>
    Swal.fire(
        'Todo correcto',
        '<?php echo e(session('Confirmacion_cambio')); ?>',
        'success'
    )
</script>
<?php endif; ?>
<?php if(session()->has('Confirmacion_eliminacion')): ?>
<script>
    Swal.fire(
        'Todo correcto',
        '<?php echo e(session('Confirmacion_eliminacion')); ?>',
        'success'
    )
</script>
<?php endif; ?><?php /**PATH D:\Git\PI_Tlacualli\TLACUALLI\resources\views/partials/alertas.blade.php ENDPATH**/ ?>