<div class="card mt-3 ms-3">
    <h3 class="ms-2 mt-2">Tipos de productos</h3>
    <ul>
        <li><a href="">Contenedores</a></li>
        <li><a href="">Abonos</a></li>
        <li><a href="">Repelentes</a></li>
        <li><a href="">Tierra</a></li>
        <li><a href="">Fauna</a></li>
    </ul>
  </div><?php /**PATH D:\Git\PI_Tlacualli\TLACUALLI\resources\views/partials/productos1/filtros.blade.php ENDPATH**/ ?>