<div class="accordion mt-3" id="accordionExample<?php echo e($i); ?>">
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($i); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($i); ?>">
                <div class="row">
                    <div class="col-1 ">
                        <img src="<?php echo e(asset('images/pdf.png')); ?>" alt="" class="mr-2" style="max-height: 20px;"> 
                    </div>
                    <div class="col-8">
                        <strong>Titulo</strong>
                        <br>
                        Documento
                    </div>
                    <div class="col-2">
                        Fecha:
                        <br>
                        10/10/10
                    </div>
                </div>
            </button>
        </h2>
        <div id="collapse<?php echo e($i); ?>" class="accordion-collapse collapse" data-bs-parent="#accordionExample<?php echo e($i); ?>">
            <div class="accordion-body d-flex justify-content-between align-items-center">
                <div>
                    <strong>Resumen</strong> 
                    <p>Se puede leer el resumen del documento</p>
                </div>
                <button class="btn btn-outline-primary"><i class="bi bi-file-earmark-pdf"></i> Acceder al documento</button>
            </div>
            
        </div>
    </div>
</div>
<?php /**PATH D:\Git\PI_Tlacualli\TLACUALLI\resources\views/partials/publicaciones/acordion_publicaciones.blade.php ENDPATH**/ ?>