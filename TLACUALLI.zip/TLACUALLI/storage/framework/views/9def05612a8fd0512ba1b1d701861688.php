

<?php /**PATH C:\GitHub\PI_Tlacualli\TLACUALLI\resources\views/partials/productos/script_productos.blade.php ENDPATH**/ ?>