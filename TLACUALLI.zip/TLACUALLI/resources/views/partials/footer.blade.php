<hr class="mt-5">
<div class="bg-brown mt-2"> 
    <div class="container-fluid">
        <div class="footer-copyright py-3">
            <div class="d-md-flex justify-content-between align-items-center py-3 text-center text-md-start">
                <div class="text-black">©2024 All Rights Reserved by <a href="#!" class="text-black"> Tlacualli.</a></div>
                <div class="copyright-links primary-hover mt-3 mt-md-0">
                    <ul class="list-inline">
                        <li class="list-inline-item ps-2"><a class="list-group-item-action text-black" href="#">Home</a></li>
                        <li class="list-inline-item ps-2"><a class="list-group-item-action text-black" href="#">Acerca de nosotros</a></li>
                        <li class="list-inline-item ps-2"><a class="list-group-item-action text-black" href="#">Comunidad</a></li>
                        <li class="list-inline-item ps-2"><a class="list-group-item-action text-black" href="#">Políticas de Privacidad</a></li>
                        <li class="list-inline-item ps-2"><a class="list-group-item-action pe-0 text-black" href="#">Términos y Condiciones</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

