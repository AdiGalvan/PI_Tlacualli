
<div class="card mt-3 ms-3">
    <h3 class="ms-2 mt-2">Categorias</h3>
        <ul>
            <li><a href="">Composta</a></li>
            <li><a href="">Lombricomposta</a></li>
            <li><a href="">Huertos</a></li>
            <li><a href="">Practicas verdes</a></li>
        </ul>
  </div>